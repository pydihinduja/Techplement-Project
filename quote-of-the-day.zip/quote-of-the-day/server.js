const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// Endpoint to get a random quote
app.get('/api/quote', async (req, res) => {
  try {
    const response = await axios.get('https://api.quotable.io/random');
    res.json(response.data);
  } catch (error) {
    res.status(500).send('Error fetching quote');
  }
});

// Endpoint to search quotes by author
app.get('/api/quotes', async (req, res) => {
  const author = req.query.author;
  try {
    const response = await axios.get(`https://api.quotable.io/quotes?author=${author}`);
    res.json(response.data);
  } catch (error) {
    res.status(500).send('Error fetching quotes');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


const path = require('path');

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'client/build')));

// The "catchall" handler: for any request that doesn't match one above, send back React's index.html file.
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname + '/client/build/index.html'));
});