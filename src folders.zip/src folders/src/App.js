import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
    const [quote, setQuote] = useState('');
    const [author, setAuthor] = useState('');

    const fetchQuote = async () => {
        try {
            const response = await fetch('https://api.quotable.io/random');
            const data = await response.json();
            setQuote(data.content);
            setAuthor(data.author);
        } catch (error) {
            setQuote('Failed to fetch quote.');
            setAuthor('');
        }
    };

    useEffect(() => {
        fetchQuote(); // Fetch a quote immediately on load
        const intervalId = setInterval(fetchQuote, 10000); // Fetch a new quote every 2 minutes

        // Clear the interval when the component unmounts
        return () => clearInterval(intervalId);
    }, []);

    return (
        <div className="quote-container">
            <div className="quote">{quote}</div>
            <div className="author">{author && `- ${author}`}</div>
        </div>
    );
}

export default App;